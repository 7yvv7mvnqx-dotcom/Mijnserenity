/* MijnSerenity 8.32.2 — scherpe Serenity hero, zonder donker vlak en compactere aansluiting
   Belangrijkste bediening in één iPad-landscape scherm.
   Minder gebruikte functies, waaronder Live varen, staan onder Meer. */
(()=>{
'use strict';
if(window.__msApprovedDashboard8280)return;
window.__msApprovedDashboard8280=true;
window.__msApprovedDashboard8263=true;
window.__msApprovedDashboard8260=true;
window.__msVictronEmbedded8319=true;

const BUILD='8.32.2';
const TOKEN='832020';
const ROOT='ms8210Start';
const STYLE='ms8280LandscapeStyle';
const $=id=>document.getElementById(id);

const icon={
 home:'<svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>',
 map:'<svg viewBox="0 0 24 24"><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z"/><path d="M9 3v15M15 6v15"/></svg>',
 route:'<svg viewBox="0 0 24 24"><circle cx="6" cy="5" r="2"/><circle cx="18" cy="19" r="2"/><path d="M8 5h4a3 3 0 0 1 0 6H9a3 3 0 0 0 0 6h7"/></svg>',
 radar:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2"/><path d="M4.2 19.8a11 11 0 0 1 15.6-15.6M7 17a7 7 0 0 1 10-10M12 12l7-7"/></svg>',
 sun:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
 pin:'<svg viewBox="0 0 24 24"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.4"/></svg>',
 cloud:'<svg viewBox="0 0 24 24"><path d="M6 18h11a4 4 0 0 0 .5-8 6 6 0 0 0-11.3-1.5A4.7 4.7 0 0 0 6 18Z"/></svg>',
 battery:'<svg viewBox="0 0 24 24"><rect x="3" y="7" width="17" height="10" rx="2"/><path d="M20 10h2v4h-2"/></svg>',
 log:'<svg viewBox="0 0 24 24"><rect x="5" y="3" width="15" height="18" rx="2"/><path d="M8 3v18M11 8h6M11 12h6M11 16h4M3 7h4M3 12h4M3 17h4"/></svg>',
 gear:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1A1.7 1.7 0 0 0 4.6 15 1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9A1.7 1.7 0 0 0 21 10h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/></svg>',
 more:'<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
 close:'<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>',
 moon:'<svg viewBox="0 0 24 24"><path d="M20 15.2A8.5 8.5 0 0 1 8.8 4a8.7 8.7 0 1 0 11.2 11.2Z"/></svg>',
 speed:'<svg viewBox="0 0 24 24"><path d="M4 17a8 8 0 1 1 16 0"/><path d="m12 14 4-4"/><circle cx="12" cy="14" r="1.4"/></svg>',
 depth:'<svg viewBox="0 0 24 24"><path d="M12 3v14"/><path d="m8 13 4 4 4-4"/><path d="M4 20c2-1 4-1 6 0s4 1 6 0 3-1 4-.5"/></svg>',
 compass:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2.1 4.9-4.9 2.1 2.1-4.9 4.9-2.1Z"/></svg>'
};

function installStyle(){
 if($(STYLE))return;
 ['ms8260ApprovedStyle','ms8263ApprovedStyle','ms8265DashboardButtonsStyle'].forEach(id=>$(id)?.remove());
 const s=document.createElement('style');s.id=STYLE;
 s.textContent=`
 :root{--msr-cyan:#1fdcff;--msr-bg:#031623;--msr-panel:#06283b;--msr-line:#0c6688;--msr-muted:#9bb8c6;--msr-green:#27d86e}
 html,body{margin:0!important;width:100%!important;height:100%!important;overflow:hidden!important;background:#02131e!important}
 body.ms8263-home-active{margin:0!important;background:#02131e!important;overflow:hidden!important;overscroll-behavior:none!important}
 body.ms8263-home-active #appView>.tabs,body.ms8263-home-active>.bottom-nav,body.ms8263-home-active #appView>.bottom-nav{display:none!important}
 #dashboard.ms8255-reference-dashboard{padding:0!important;margin:0!important;max-width:none!important;background:#02131e!important;overflow:hidden!important}
 #${ROOT}{display:block!important;position:fixed!important;inset:0!important;width:100vw!important;max-width:none!important;height:100dvh!important;min-height:100dvh!important;margin:0!important;padding:0!important;background:#02131e!important;color:#fff!important;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;overflow:hidden!important;-webkit-font-smoothing:antialiased}
 #${ROOT} *{box-sizing:border-box}
 #${ROOT} button{font:inherit;-webkit-tap-highlight-color:transparent;touch-action:manipulation}
 #${ROOT} svg{display:block;width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
 #${ROOT} .msr-shell{display:grid;grid-template-columns:14.36vw minmax(0,1fr);grid-template-rows:clamp(230px,30vh,350px) minmax(0,1fr);width:100%;height:100%;padding-bottom:0;background:linear-gradient(145deg,#06283a 0,#031620 56%,#02111b 100%);overflow:hidden}
 #${ROOT} .msr-side{grid-row:1/3;grid-column:1;display:flex;flex-direction:column;min-height:0;border-right:1px solid rgba(35,177,222,.38);background:linear-gradient(180deg,#07324b 0,#031a2a 58%,#041727 100%);box-shadow:inset -1px 0 rgba(255,255,255,.03)}
 #${ROOT} .msr-brand{height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:18px 12px 13px}
 #${ROOT} .msr-brand strong{font-family:Georgia,"Times New Roman",serif;font-size:45px;line-height:.85;font-style:italic;font-weight:500;letter-spacing:-.06em;text-shadow:0 2px 14px rgba(255,255,255,.12)}
 #${ROOT} .msr-wave{width:118px;height:16px;margin-top:4px;border-bottom:4px solid #86e9ff;border-radius:0 0 90% 55%;transform:skewX(-16deg)}
 #${ROOT} .msr-brand small{margin-top:11px;color:#e7f6fb;font-size:9px;letter-spacing:.21em;text-transform:uppercase;font-weight:800}
 #${ROOT} .msr-nav{display:flex;flex:1;min-height:0;flex-direction:column;gap:4px;padding:0 10px;overflow:auto;scrollbar-width:none}
 #${ROOT} .msr-nav::-webkit-scrollbar{display:none}
 #${ROOT} .msr-nav button{display:grid;grid-template-columns:32px 1fr;align-items:center;gap:12px;min-height:56px;padding:0 16px;border:1px solid transparent;border-radius:7px;background:transparent;color:#fff;text-align:left;font-size:15px;font-weight:650;cursor:pointer}
 #${ROOT} .msr-nav button svg{width:25px;height:25px;stroke-width:2}
 #${ROOT} .msr-nav button.active{position:relative;background:linear-gradient(90deg,rgba(7,146,190,.70),rgba(6,62,89,.74));border-color:rgba(37,214,255,.34);color:#fff}
 #${ROOT} .msr-nav button.active:before{content:"";position:absolute;left:-10px;top:-1px;bottom:-1px;width:5px;background:#28ddff;box-shadow:0 0 16px rgba(40,221,255,.65)}
 #${ROOT} .msr-side-foot{padding:11px 12px 18px;text-align:center;color:#5f9dbb;font-size:10px;letter-spacing:.10em}
 #${ROOT} .msr-side-foot .sun{font-size:34px;color:#d5f7ff;line-height:1}
 #${ROOT} .msr-side-foot strong{display:block;margin-top:4px;color:#fff;font-family:Georgia,serif;font-size:20px;font-weight:500;letter-spacing:.02em}
 #${ROOT} .msr-hero{grid-column:2;grid-row:1;position:relative;overflow:hidden;background:url('/serenity-dashboard-boat-sharp-20260927.jpg?v=${TOKEN}') center 58%/cover no-repeat;isolation:isolate}
 #${ROOT} .msr-hero-bg{position:absolute;inset:0;z-index:0;width:100%;height:100%;object-fit:cover;object-position:center 58%;display:block;pointer-events:none}
 #${ROOT} .msr-hero:before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(2,19,30,.50) 0,rgba(2,19,30,.28) 30%,rgba(2,19,30,.08) 56%,rgba(2,14,23,.03) 100%)}
 #${ROOT} .msr-hero:after{display:none!important}
 #${ROOT} .msr-hero-copy{display:none!important}
 #${ROOT} .msr-hero-copy{display:none!important;position:absolute;left:1.75vw;bottom:1.65vh;z-index:2;width:min(27vw,390px);padding:9px 18px 9px 12px;border:1px solid rgba(92,196,229,.16);border-radius:11px;background:linear-gradient(90deg,rgba(2,19,30,.50),rgba(2,19,30,.34));box-shadow:0 8px 22px rgba(0,0,0,.15);-webkit-backdrop-filter:blur(7px);backdrop-filter:blur(7px);text-shadow:0 2px 10px rgba(0,0,0,.80)}
 #${ROOT} .msr-hero-copy strong{display:block;font-size:1.58vw;line-height:1.05}
 #${ROOT} .msr-hero-copy span{display:block;margin-top:5px;font-size:.98vw;font-weight:620}
 #${ROOT} .msr-hero-copy em{display:block;margin-top:.75vh;font-size:.88vw;font-style:italic;color:#f1f7fa}
 #${ROOT} .msr-hero-info{position:absolute;right:1.55vw;top:2.60vh;z-index:2;display:grid;padding:14px 4px 14px 36px;background:linear-gradient(270deg,rgba(2,19,30,.88) 0,rgba(2,19,30,.54) 66%,rgba(2,19,30,0) 100%);box-shadow:22px 0 35px 16px rgba(2,19,30,.25);grid-template-columns:48px auto;grid-template-areas:"date date" "moon time" "moon temp" "pin place";align-items:center;column-gap:10px;color:#fff;text-align:right;text-shadow:0 3px 14px rgba(0,0,0,.72)}
 #${ROOT} .msr-hero-date{grid-area:date;margin-bottom:4px;font-size:12px;font-weight:750}
 #${ROOT} .msr-hero-time{grid-area:time;font-size:32px;line-height:1;font-weight:800}
 #${ROOT} .msr-hero-moon{grid-area:moon;font-size:42px;line-height:1;align-self:end}
 #${ROOT} .msr-hero-temp{grid-area:temp;margin-top:5px;font-size:16px;font-weight:800}
 #${ROOT} .msr-hero-place{grid-area:place;margin-top:8px;font-size:12px;font-weight:700}
 #${ROOT} .msr-hero-pin{grid-area:pin;margin-top:8px;font-size:17px}
 #${ROOT} .ms8263-main{grid-column:2;grid-row:2;display:grid!important;grid-template-rows:clamp(142px,19vh,178px) minmax(0,1fr);gap:.55vh;min-height:0;padding:0 1.25vw 9.1vh!important;background:linear-gradient(180deg,#062033 0,#031521 100%)!important;overflow:hidden!important}
 #${ROOT} .msr-panel{border:1px solid rgba(26,128,165,.70);border-radius:17px;background:linear-gradient(145deg,rgba(4,42,61,.96),rgba(2,24,38,.97));box-shadow:inset 0 1px rgba(255,255,255,.04),0 10px 22px rgba(0,0,0,.10);overflow:hidden}
 #${ROOT} .msr-kicker{display:flex;align-items:center;gap:8px;color:#74e6ff;font-size:9px;font-weight:900;letter-spacing:.19em;text-transform:uppercase}
 #${ROOT} .msr-kicker .ico{font-size:18px;letter-spacing:0}
 #${ROOT} .msr-quick{padding:13px 14px 14px}
 #${ROOT} .msr-vrm-live{position:relative;display:grid;grid-template-rows:44px minmax(0,1fr);min-height:0;height:100%;overflow:hidden;border:1px solid rgba(26,128,165,.70);border-radius:17px;background:#01080d;box-shadow:inset 0 1px rgba(255,255,255,.04),0 10px 22px rgba(0,0,0,.20)}
 #${ROOT} .msr-vrm-live iframe{display:block;width:100%!important;height:100%!important;min-height:0;border:0;background:#000}
 #${ROOT} .msr-quick-head{display:flex;align-items:center;justify-content:space-between;margin:0 3px 10px}
 #${ROOT} .msr-quick-head strong{font-size:12px;letter-spacing:.18em}
 #${ROOT} .msr-edit{border:0;background:transparent;color:#65e5ff;font-size:11px;font-weight:700}
 #${ROOT} .ms8263-features{display:grid!important;grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:12px!important;margin:0!important}
 #${ROOT} .ms8263-feature{display:flex!important;min-width:0!important;min-height:clamp(88px,11.4vh,122px)!important;padding:16px 9px 10px!important;border:1px solid rgba(155,232,255,.38)!important;border-radius:12px!important;flex-direction:column!important;align-items:center!important;justify-content:flex-start!important;gap:7px!important;color:#fff!important;text-align:center!important;cursor:pointer!important;box-shadow:inset 0 1px rgba(255,255,255,.14),0 9px 18px rgba(0,0,0,.14)!important}
 #${ROOT} .ms8263-feature>svg{width:33px!important;height:33px!important;margin:1px 0 3px;stroke-width:2!important}
 #${ROOT} .ms8263-feature .copy strong{display:block;font-size:15px;line-height:1.05}
 #${ROOT} .ms8263-feature .copy small{display:block;margin-top:7px;color:#e1edf1;font-size:10px;line-height:1.15;white-space:normal;overflow:hidden;overflow-wrap:anywhere}
 #${ROOT} .ms8263-feature .chev{display:grid!important;place-items:center;width:34px;height:34px;margin-top:auto;border:1px solid rgba(255,255,255,.26);border-radius:50%;background:rgba(255,255,255,.12);font-size:21px;line-height:1}
 #${ROOT} .ms8263-feature.green{background:linear-gradient(145deg,#06a23f,#057637)!important}
 #${ROOT} .ms8263-feature.cyan{background:linear-gradient(145deg,#0781b0,#075b7f)!important}
 #${ROOT} .ms8263-feature.orange{background:linear-gradient(145deg,#d36a0d,#914608)!important}
 #${ROOT} .ms8263-feature.purple{background:linear-gradient(145deg,#724ca4,#50317b)!important}

 #${ROOT} .ms8263-feature.navy{background:linear-gradient(145deg,#0880bd,#075a8d)!important}
 /* 8.30.12: kaarten schuiven omhoog; het bovenste deel blijft zichtbaar op de voorgrond.
    De kaart beweegt uitsluitend omhoog, zodat de onderzijde binnen het eigen Snel-naar-gebied blijft. */
 #${ROOT} .ms8263-main{position:relative!important;z-index:4!important;overflow:visible!important}
 #${ROOT} .msr-quick{position:relative!important;z-index:12!important;overflow:visible!important}
 #${ROOT} .ms8263-features{position:relative!important;z-index:13!important;overflow:visible!important}
 #${ROOT} .ms8263-feature{position:relative!important;z-index:1!important;transform:translateY(0);transition:transform 280ms cubic-bezier(.2,.8,.2,1),box-shadow 280ms ease;will-change:transform}
 #${ROOT} .ms8263-feature:hover,#${ROOT} .ms8263-feature.msr-feature-expanded{z-index:40!important;transform:translateY(-46px);box-shadow:inset 0 1px rgba(255,255,255,.20),0 18px 30px rgba(0,0,0,.30)!important}
 #${ROOT} .ms8263-feature .copy small{overflow:hidden!important}
 @media (hover:none),(pointer:coarse){
   #${ROOT} .ms8263-feature:hover{transform:translateY(0)}
   #${ROOT} .ms8263-feature.msr-feature-expanded{z-index:40!important;transform:translateY(-46px)}
 }

 #${ROOT} .msr-row{display:none!important;grid-template-columns:1.03fr 1.03fr 1.42fr;gap:11px;min-height:0}
 #${ROOT} .msr-row-bottom{grid-template-columns:1.08fr .98fr 1.16fr}
 #${ROOT} .msr-card{display:flex;min-height:0;flex-direction:column;padding:13px 13px 9px}
 #${ROOT} .msr-card-title{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
 #${ROOT} .msr-live{display:flex;align-items:center;gap:5px;padding:4px 8px;border-radius:999px;background:rgba(5,55,66,.8);font-size:9px;color:#d7f4dd}
 #${ROOT} .msr-live i{width:8px;height:8px;border-radius:50%;background:#12d64d;box-shadow:0 0 8px rgba(18,214,77,.65)}
 #${ROOT} .msr-mainline{display:flex;align-items:center;gap:16px;padding:5px 12px 8px}
 #${ROOT} .msr-mainline .bigico{font-size:39px;line-height:1}
 #${ROOT} .msr-mainline strong{font-size:21px;line-height:1.05}
 #${ROOT} .msr-mainline small{display:block;margin-top:4px;color:#afc4cd;font-size:11px}
 #${ROOT} .msr-minis{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:auto}
 #${ROOT} .msr-mini{min-width:0;padding:9px 6px;border:1px solid rgba(79,153,183,.28);border-radius:10px;background:rgba(13,49,66,.62);text-align:center}
 #${ROOT} .msr-mini small{display:block;color:#c1d0d6;font-size:9px}
 #${ROOT} .msr-mini strong{display:block;margin-top:4px;font-size:12px}
 #${ROOT} .msr-action{display:flex;align-items:center;justify-content:center;gap:6px;min-height:30px;margin-top:auto;border:1px solid rgba(56,194,235,.66);border-radius:9px;background:rgba(5,39,57,.72);color:#fff;font-size:10px;font-weight:800}
 #${ROOT} .msr-weather-main{display:flex;align-items:center;gap:14px;padding:2px 15px 7px}
 #${ROOT} .msr-weather-icon{font-size:46px}
 #${ROOT} .msr-weather-main strong{font-size:24px}
 #${ROOT} .msr-weather-main small{display:block;margin-top:3px;color:#c2d1d7;font-size:11px}
 #${ROOT} .msr-rings{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;align-items:start;padding:0 4px}
 #${ROOT} .msr-gauge{text-align:center}
 #${ROOT} .msr-ring{--p:50;position:relative;width:72px;height:72px;margin:0 auto 5px;border-radius:50%;background:conic-gradient(#24dffb calc(var(--p)*1%),#0a4661 0);box-shadow:inset 0 0 0 8px rgba(2,31,45,.95)}
 #${ROOT} .msr-ring.low{background:conic-gradient(#ff9b45 calc(var(--p)*1%),#66321d 0);box-shadow:inset 0 0 0 8px rgba(54,24,16,.96),0 0 16px rgba(255,143,55,.18)}
 #${ROOT} .msr-ring.low:after{background:#3a211b}
 #${ROOT} .msr-gauge.low label{color:#ffc08b}
 #${ROOT} .msr-ring:after{content:"";position:absolute;inset:11px;border-radius:50%;background:#06283a}
 #${ROOT} .msr-ring strong{position:absolute;inset:0;z-index:2;display:grid;place-items:center;font-size:17px}
 #${ROOT} .msr-gauge label{display:block;font-size:10px;font-weight:700}
 #${ROOT} .msr-gauge small{display:block;margin-top:2px;color:#aec2ca;font-size:8.5px;line-height:1.25}
 #${ROOT} .msr-tankline{display:grid;grid-template-columns:30px 92px 1fr 42px 18px;align-items:center;gap:6px;min-height:39px;border-bottom:1px solid rgba(255,255,255,.055)}
 #${ROOT} .msr-tankline .ticon{display:grid;place-items:center;width:28px;height:28px;border-radius:7px;background:rgba(20,105,139,.35);font-size:16px}
 #${ROOT} .msr-tankline strong{font-size:10.5px}
 #${ROOT} .msr-bar{height:13px;border-radius:999px;background:#355565;overflow:hidden;box-shadow:inset 0 1px 4px rgba(0,0,0,.45)}
 #${ROOT} .msr-bar i{display:block;height:100%;width:var(--p);border-radius:inherit;background:linear-gradient(90deg,#ff4d41,#ff6c5f)}
 #${ROOT} .msr-tankline.water .msr-bar i{background:linear-gradient(90deg,#15c6ed,#46e7ff)}
 #${ROOT} .msr-tankline small{font-size:9px;color:#b2c3cb}
 #${ROOT} .msr-status-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 18px;padding:2px 5px}
 #${ROOT} .msr-status-item{display:grid;grid-template-columns:18px 1fr;gap:7px;align-items:start}
 #${ROOT} .msr-check{display:grid;place-items:center;width:17px;height:17px;border-radius:50%;background:#16b94f;color:white;font-size:11px;box-shadow:0 0 8px rgba(22,185,79,.30)}
 #${ROOT} .msr-status-item strong{display:block;font-size:10px}
 #${ROOT} .msr-status-item small{display:block;margin-top:2px;color:#a9c0ca;font-size:8.5px}
 #${ROOT} .msr-upcoming{display:grid;gap:5px}
 #${ROOT} .msr-upcoming-item{display:grid;grid-template-columns:28px 84px minmax(0,1fr);align-items:center;min-height:30px;padding:0 8px;border:1px solid rgba(93,166,195,.24);border-radius:9px;background:rgba(12,49,67,.54);font-size:9px}
 #${ROOT} .msr-upcoming-item .uico{font-size:15px}
 #${ROOT} .msr-upcoming-item strong{font-size:9px}
 #${ROOT} .msr-hidden-anchor,#${ROOT} #ms8264LiveInstruments{position:absolute!important;left:-99999px!important;top:-99999px!important;width:1px!important;height:1px!important;overflow:hidden!important;opacity:0!important;pointer-events:none!important}
 #${ROOT} .ms8263-welcome{position:absolute!important;left:-99999px!important;top:-99999px!important;width:1px!important;height:1px!important;overflow:visible!important;border:0!important;background:none!important}
 #${ROOT} .ms8263-start{display:block!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important}
 #${ROOT} .msqa8267#msQuickAsk8267{position:fixed!important;z-index:10010!important;left:calc(14.36vw + 1.25vw)!important;right:1.25vw!important;bottom:max(7px,env(safe-area-inset-bottom))!important;height:52px!important;min-height:52px!important;margin:0!important;padding:5px 184px 5px 172px!important;border:1px solid rgba(45,175,218,.30)!important;border-radius:12px!important;background:linear-gradient(90deg,rgba(5,54,79,.60),rgba(3,31,46,.48))!important;-webkit-backdrop-filter:blur(9px)!important;backdrop-filter:blur(9px)!important;box-shadow:0 10px 24px rgba(0,0,0,.18)!important;overflow:hidden!important}
 #${ROOT} .msqa8267-label{position:absolute!important;left:1.15vw!important;top:0!important;bottom:0!important;display:flex!important;align-items:center!important;width:10.9vw!important;margin:0!important;color:#fff!important;font-size:13px!important;font-weight:800!important;letter-spacing:0!important;text-transform:none!important}
 #${ROOT} .msqa8267-label:before{font-size:18px!important;margin-right:8px}
 #${ROOT} .msqa8270-badge{display:none!important}
 #${ROOT} .msqa8267-row{display:grid!important;grid-template-columns:minmax(0,1fr) 40px!important;gap:7px!important;min-height:42px!important;height:42px!important;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important}
 #${ROOT} .msqa8267-spark{display:none!important}
 #${ROOT} .msqa8267 input{height:42px!important;padding:0 14px!important;border:1px solid rgba(81,149,177,.30)!important;border-radius:9px!important;background:rgba(17,60,78,.42)!important;color:white!important;font-size:12px!important;font-weight:600!important;-webkit-backdrop-filter:blur(5px)!important;backdrop-filter:blur(5px)!important}
 #${ROOT} .msqa8267-send{width:40px!important;height:42px!important;min-width:40px!important;min-height:42px!important;border-radius:9px!important;background:linear-gradient(135deg,#20c9ef,#23dffe)!important}
 #${ROOT} .msqa8267-examples{position:absolute!important;right:.55vw!important;top:5px!important;width:11.7vw!important;height:42px!important;margin:0!important;padding:3px 7px!important;border:1px solid rgba(69,150,182,.22)!important;border-radius:8px!important;background:rgba(9,45,63,.40)!important;color:#d9e7ed!important;font-size:7.5px!important;line-height:1.12!important;overflow:hidden!important;-webkit-backdrop-filter:blur(5px)!important;backdrop-filter:blur(5px)!important}
 #${ROOT} .msqa8267-examples strong{display:block;margin-bottom:1px;color:#fff;font-size:8.4px}
 #${ROOT} .msqa8267-result{position:fixed!important;left:245px!important;right:225px!important;bottom:96px!important;max-height:140px!important;margin:0!important;z-index:10011!important;font-size:11px!important;overflow:auto!important}
 #${ROOT} .ms8271-tools{position:absolute!important;right:13.05vw!important;top:5px!important;display:block!important;width:40px!important;height:42px!important;margin:0!important}
 #${ROOT} #ms8271Mic{display:grid!important;place-items:center!important;width:40px!important;height:42px!important;min-width:40px!important;min-height:42px!important;padding:0!important;border:1px solid rgba(94,169,198,.30)!important;border-radius:9px!important;background:rgba(12,54,72,.48)!important;color:#fff!important;-webkit-backdrop-filter:blur(5px)!important;backdrop-filter:blur(5px)!important}
 #${ROOT} #ms8271Mic svg{width:23px!important;height:23px!important}
 #${ROOT} #ms8271Mic span,#${ROOT} #ms8271Clear,#${ROOT} .ms8271-speak,#${ROOT} .ms8271-ai-note,#${ROOT} .ms8271-voice-status{display:none!important}
 @media(max-height:760px) and (orientation:landscape){
   #${ROOT} .msr-shell{grid-template-columns:188px minmax(0,1fr);grid-template-rows:250px minmax(0,1fr);padding-bottom:0}
   #${ROOT} .msr-brand{height:150px}
   #${ROOT} .msr-brand strong{font-size:38px}
   #${ROOT} .msr-nav button{min-height:46px;font-size:13px}
   #${ROOT} .msr-hero-copy{bottom:20px}
   #${ROOT} .msr-hero-copy strong{font-size:22px}
   #${ROOT} .msr-hero-info{top:28px}
   #${ROOT} .ms8263-main{grid-template-rows:1fr 1fr 1fr;gap:8px;padding:9px 12px 82px!important}
   #${ROOT} .ms8263-feature{min-height:112px!important;padding-top:10px!important}
   #${ROOT} .ms8263-feature>svg{width:28px!important;height:28px!important}
   #${ROOT} .msr-card{padding:9px 10px 7px}
   #${ROOT} .msr-ring{width:58px;height:58px}
   #${ROOT} .msr-tankline{min-height:32px}
   #${ROOT} .msqa8267{height:66px!important;bottom:8px!important;padding-top:7px!important;padding-bottom:7px!important}
   #${ROOT} .msqa8267-row,#${ROOT} .msqa8267 input,#${ROOT} .msqa8267-send,#${ROOT} #ms8271Mic{height:50px!important;min-height:50px!important}
 }
 @media(max-width:900px) and (orientation:portrait){
   body.ms8263-home-active{overflow:auto!important}
   #${ROOT}{position:relative!important;height:auto!important;min-height:100dvh!important;overflow:auto!important}
   #${ROOT} .msr-shell{display:block;height:auto;min-height:100dvh;padding-bottom:calc(118px + env(safe-area-inset-bottom))}
   #${ROOT} .msr-side{display:none}
   #${ROOT} .msr-hero{height:260px}
   #${ROOT} .ms8263-main{display:block!important;overflow:visible!important;padding:12px 12px 22px!important}
   #${ROOT} .msr-quick,#${ROOT} .msr-row{margin-bottom:10px}
   #${ROOT} .ms8263-features{grid-template-columns:repeat(2,minmax(0,1fr))!important}
   #${ROOT} .msr-row,#${ROOT} .msr-row-bottom{display:block}
   #${ROOT} .msr-card{margin-bottom:10px}
   #${ROOT} .msqa8267#msQuickAsk8267{left:8px!important;right:8px!important;bottom:max(8px,env(safe-area-inset-bottom))!important;height:58px!important;min-height:58px!important;padding:6px 66px 6px 8px!important;border-radius:14px!important}
   #${ROOT} .msqa8267-row{height:46px!important;min-height:46px!important;grid-template-columns:minmax(0,1fr) 46px!important;gap:8px!important}
   #${ROOT} .msqa8267 input{height:46px!important;min-height:46px!important;padding:0 12px!important;font-size:12px!important}
   #${ROOT} .msqa8267-send{width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important}
   #${ROOT} .msqa8267-result{left:12px!important;right:12px!important;bottom:78px!important;max-height:34vh!important}
   #${ROOT} .msqa8267-label,#${ROOT} .msqa8267-examples,#${ROOT} .ms8271-tools{display:none!important}
 }

 #${ROOT} .msr-heater{display:grid;grid-template-columns:88px 1fr 62px;align-items:center;gap:7px;margin-top:5px}
 #${ROOT} .msr-heater button{height:32px;border:1px solid rgba(65,172,211,.46);border-radius:9px;background:rgba(8,50,70,.82);color:#e8f8ff;font-size:10px;font-weight:850}
 #${ROOT} .msr-heater-power.on,#${ROOT} .msr-heater-auto.on{border-color:rgba(45,225,116,.72);background:rgba(19,126,66,.72);box-shadow:0 0 12px rgba(39,216,110,.16)}
 #${ROOT} .msr-heater-temp{display:grid;grid-template-columns:32px 1fr 32px;align-items:center;height:32px;border:1px solid rgba(65,172,211,.34);border-radius:9px;background:rgba(8,43,61,.72);overflow:hidden}
 #${ROOT} .msr-heater-temp button{height:30px;border:0;border-radius:0;background:transparent;font-size:17px}
 #${ROOT} .msr-heater-temp strong{text-align:center;font-size:14px}
 #${ROOT} .ms8263-feature .copy{min-width:0;width:100%}
 #${ROOT} .ms8263-feature .copy small{min-height:2.3em}
 #${ROOT} .msqa8267#msQuickAsk8267{bottom:max(8px,env(safe-area-inset-bottom))!important}
 @media(max-height:760px) and (orientation:landscape){
   #${ROOT} .msr-shell{grid-template-rows:17dvh minmax(0,1fr)!important}
   #${ROOT} .msr-brand{height:102px!important;padding-top:8px!important}
   #${ROOT} .msr-brand strong{font-size:38px!important}
   #${ROOT} .msr-nav button{min-height:38px!important}
   #${ROOT} .ms8263-main{grid-template-rows:108px minmax(360px,1fr)!important;gap:6px!important;padding:6px 12px 66px!important}
   #${ROOT} .msr-quick{padding:9px 11px!important}
   #${ROOT} .msr-quick-head{margin-bottom:7px!important}
   #${ROOT} .ms8263-features{gap:8px!important}
   #${ROOT} .ms8263-feature{min-height:76px!important;padding:6px 7px 5px!important;gap:2px!important}
   #${ROOT} .ms8263-feature>svg{width:25px!important;height:25px!important;margin:0!important}
   #${ROOT} .ms8263-feature .copy strong{font-size:13px!important}
   #${ROOT} .ms8263-feature .copy small{margin-top:3px!important;font-size:8.5px!important;line-height:1.12!important}
   #${ROOT} .ms8263-feature .chev{width:25px!important;height:25px!important;font-size:16px!important}
   #${ROOT} .msr-card{padding:8px 10px 6px!important}
   #${ROOT} .msr-card-title{margin-bottom:4px!important}
   #${ROOT} .msr-mainline{padding:1px 8px 3px!important}
   #${ROOT} .msr-mainline .bigico{font-size:28px!important}
   #${ROOT} .msr-mainline strong{font-size:16px!important}
   #${ROOT} .msr-minis{gap:3px!important}
   #${ROOT} .msr-mini{padding:5px 4px!important}
   #${ROOT} .msr-action{min-height:24px!important;margin-top:4px!important}
   #${ROOT} .msr-ring{width:54px!important;height:54px!important}
   #${ROOT} .msr-ring strong{font-size:13px!important}
   #${ROOT} .msr-weather-icon{font-size:34px!important}
   #${ROOT} .msr-weather-main{padding:0 9px 3px!important}
   #${ROOT} .msr-tankline{min-height:27px!important}
   #${ROOT} .msr-status-grid{gap:3px 12px!important}
   #${ROOT} .msr-status-item small{margin-top:0!important}
   #${ROOT} .msr-upcoming{gap:3px!important}
   #${ROOT} .msr-upcoming-item{min-height:24px!important}
   #${ROOT} .msqa8267#msQuickAsk8267{height:52px!important;min-height:52px!important;padding-top:5px!important;padding-bottom:5px!important}
   #${ROOT} .msqa8267-row,#${ROOT} .msqa8267 input,#${ROOT} .msqa8267-send,#${ROOT} #ms8271Mic{height:42px!important;min-height:42px!important}
 }

 /* 8.30.8 — iPhone: leesbaarheid gaat vóór alles-in-één-scherm. */
 @media(max-width:600px){
   html{height:auto!important;overflow:auto!important}
   body.ms8263-home-active{height:auto!important;min-height:100dvh!important;overflow:auto!important}
   #${ROOT}{position:relative!important;inset:auto!important;width:100%!important;height:auto!important;min-height:100dvh!important;overflow:auto!important}
   #${ROOT} .msr-shell{display:block!important;height:auto!important;min-height:100dvh!important;overflow:visible!important;padding-bottom:calc(92px + env(safe-area-inset-bottom))!important}
   #${ROOT} .msr-side{display:none!important}
   #${ROOT} .msr-hero{height:190px!important;min-height:190px!important;border-bottom:1px solid rgba(35,177,222,.35)}
   #${ROOT} .msr-hero-copy{left:10px!important;right:auto!important;bottom:10px!important;width:min(68vw,270px)!important;max-width:calc(100% - 100px)!important;padding:9px 11px!important;border-radius:10px!important;background:linear-gradient(90deg,rgba(2,19,30,.72),rgba(2,19,30,.42))!important}
   #${ROOT} .msr-hero-copy strong{font-size:25px!important;line-height:1.02!important}
   #${ROOT} .msr-hero-copy span{margin-top:4px!important;font-size:14px!important;line-height:1.2!important}
   #${ROOT} .msr-hero-copy em{margin-top:5px!important;font-size:12px!important;line-height:1.2!important}
   #${ROOT} .msr-hero-info{right:8px!important;top:8px!important;padding:8px 2px 8px 14px!important;grid-template-columns:26px auto!important;column-gap:5px!important;background:linear-gradient(270deg,rgba(2,19,30,.78),rgba(2,19,30,.28))!important;box-shadow:none!important}
   #${ROOT} .msr-hero-date{font-size:10px!important}
   #${ROOT} .msr-hero-time{font-size:25px!important}
   #${ROOT} .msr-hero-moon{font-size:28px!important}
   #${ROOT} .msr-hero-temp{font-size:14px!important}
   #${ROOT} .msr-hero-place{margin-top:4px!important;max-width:112px!important;font-size:10px!important;line-height:1.15!important}
   #${ROOT} .msr-hero-pin{margin-top:4px!important;font-size:14px!important}
   #${ROOT} .ms8263-main{display:block!important;overflow:visible!important;padding:10px 9px calc(92px + env(safe-area-inset-bottom))!important}
   #${ROOT} .msr-panel{border-radius:14px!important}
   #${ROOT} .msr-quick{margin-bottom:9px!important;padding:11px!important}
   #${ROOT} .msr-quick-head{margin:0 2px 9px!important}
   #${ROOT} .msr-quick-head strong{font-size:14px!important;letter-spacing:.12em!important}
   #${ROOT} .msr-edit{font-size:12px!important}
   #${ROOT} .ms8263-features{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}
   #${ROOT} .ms8263-feature{min-height:108px!important;padding:11px 6px 8px!important;gap:5px!important;border-radius:12px!important}
   #${ROOT} .ms8263-feature>svg{width:31px!important;height:31px!important;margin:0 0 2px!important}
   #${ROOT} .ms8263-feature .copy strong{font-size:15px!important;line-height:1.08!important}
   #${ROOT} .ms8263-feature .copy small{min-height:0!important;margin-top:4px!important;font-size:10.5px!important;line-height:1.18!important}
   #${ROOT} .ms8263-feature .chev{width:26px!important;height:26px!important;font-size:17px!important}
   #${ROOT} .msr-row,#${ROOT} .msr-row-bottom{display:block!important;margin-bottom:0!important}
   #${ROOT} .msr-card{min-height:auto!important;margin-bottom:9px!important;padding:11px 11px 9px!important}
   #${ROOT} .msr-card-title{margin-bottom:7px!important}
   #${ROOT} .msr-kicker{font-size:10.5px!important;letter-spacing:.15em!important}
   #${ROOT} .msr-kicker .ico{font-size:18px!important}
   #${ROOT} .msr-live{font-size:10px!important}
   #${ROOT} .msr-mainline{gap:12px!important;padding:5px 8px 9px!important}
   #${ROOT} .msr-mainline .bigico{font-size:38px!important}
   #${ROOT} .msr-mainline strong{font-size:22px!important}
   #${ROOT} .msr-mainline small{font-size:12px!important;line-height:1.2!important}
   #${ROOT} .msr-minis{gap:6px!important}
   #${ROOT} .msr-mini{padding:8px 5px!important}
   #${ROOT} .msr-mini small{font-size:10px!important}
   #${ROOT} .msr-mini strong{font-size:13px!important}
   #${ROOT} .msr-action{min-height:38px!important;margin-top:8px!important;font-size:11px!important}
   #${ROOT} .msr-weather-main{gap:12px!important;padding:3px 9px 9px!important}
   #${ROOT} .msr-weather-icon{font-size:43px!important}
   #${ROOT} .msr-weather-main strong{font-size:27px!important}
   #${ROOT} .msr-weather-main small{font-size:12px!important}
   #${ROOT} .msr-rings{gap:7px!important}
   #${ROOT} .msr-ring{width:70px!important;height:70px!important}
   #${ROOT} .msr-ring strong{font-size:16px!important}
   #${ROOT} .msr-gauge label{font-size:10.5px!important}
   #${ROOT} .msr-gauge small{font-size:9px!important}
   #${ROOT} .msr-tankline{grid-template-columns:30px 76px minmax(72px,1fr) 42px 16px!important;gap:5px!important;min-height:40px!important}
   #${ROOT} .msr-tankline strong{font-size:10.5px!important}
   #${ROOT} .msr-tankline small{font-size:9.5px!important}
   #${ROOT} .msr-status-grid{grid-template-columns:1fr!important;gap:8px!important;padding:3px 4px!important}
   #${ROOT} .msr-status-item{grid-template-columns:20px 1fr!important;gap:8px!important}
   #${ROOT} .msr-status-item strong{font-size:11px!important}
   #${ROOT} .msr-status-item small{font-size:9.5px!important;line-height:1.2!important}
   #${ROOT} .msr-upcoming{gap:6px!important}
   #${ROOT} .msr-upcoming-item{grid-template-columns:28px 74px minmax(0,1fr)!important;min-height:36px!important;padding:0 7px!important;font-size:10px!important}
   #${ROOT} .msr-upcoming-item strong{font-size:10px!important}
   #${ROOT} .msr-heater{grid-template-columns:82px minmax(0,1fr) 58px!important;gap:6px!important}
   #${ROOT} .msr-heater button{font-size:10px!important}
   #${ROOT} .msqa8267#msQuickAsk8267{left:7px!important;right:7px!important;bottom:max(7px,env(safe-area-inset-bottom))!important;height:62px!important;min-height:62px!important;padding:7px!important;border-radius:14px!important;background:linear-gradient(90deg,rgba(5,54,79,.92),rgba(3,31,46,.90))!important}
   #${ROOT} .msqa8267-row{height:48px!important;min-height:48px!important;grid-template-columns:minmax(0,1fr) 48px!important;gap:7px!important}
   #${ROOT} .msqa8267 input{height:48px!important;min-height:48px!important;padding:0 13px!important;font-size:14px!important}
   #${ROOT} .msqa8267-send{width:48px!important;height:48px!important;min-width:48px!important;min-height:48px!important}
   #${ROOT} .msqa8267-result{left:10px!important;right:10px!important;bottom:78px!important;max-height:38vh!important;font-size:12px!important}
   #${ROOT} .msqa8267-label,#${ROOT} .msqa8267-examples,#${ROOT} .ms8271-tools{display:none!important}
 }
 @media(max-width:950px) and (orientation:landscape) and (max-height:520px){
   html{height:auto!important;overflow:auto!important}
   body.ms8263-home-active{height:auto!important;min-height:100dvh!important;overflow:auto!important}
   #${ROOT}{position:relative!important;inset:auto!important;width:100%!important;height:auto!important;min-height:100dvh!important;overflow:auto!important}
   #${ROOT} .msr-shell{display:block!important;height:auto!important;min-height:100dvh!important;overflow:visible!important;padding-bottom:calc(76px + env(safe-area-inset-bottom))!important}
   #${ROOT} .msr-side{display:none!important}
   #${ROOT} .msr-hero{height:150px!important;min-height:150px!important}
   #${ROOT} .msr-hero-copy{left:12px!important;bottom:10px!important;width:290px!important;max-width:48vw!important;padding:8px 11px!important}
   #${ROOT} .msr-hero-copy strong{font-size:22px!important}
   #${ROOT} .msr-hero-copy span{font-size:13px!important}
   #${ROOT} .msr-hero-copy em{font-size:11px!important}
   #${ROOT} .msr-hero-info{right:12px!important;top:10px!important;padding:7px 2px 7px 14px!important;grid-template-columns:26px auto!important}
   #${ROOT} .msr-hero-time{font-size:25px!important}
   #${ROOT} .msr-hero-moon{font-size:28px!important}
   #${ROOT} .msr-hero-temp{font-size:14px!important}
   #${ROOT} .ms8263-main{display:block!important;overflow:visible!important;padding:8px 10px calc(76px + env(safe-area-inset-bottom))!important}
   #${ROOT} .msr-quick{margin-bottom:8px!important;padding:9px 10px!important}
   #${ROOT} .ms8263-features{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:7px!important}
   #${ROOT} .ms8263-feature{min-height:92px!important;padding:8px 5px 6px!important;gap:3px!important}
   #${ROOT} .ms8263-feature>svg{width:27px!important;height:27px!important}
   #${ROOT} .ms8263-feature .copy strong{font-size:14px!important}
   #${ROOT} .ms8263-feature .copy small{margin-top:3px!important;font-size:9.5px!important}
   #${ROOT} .ms8263-feature .chev{width:24px!important;height:24px!important;font-size:15px!important}
   #${ROOT} .msr-row,#${ROOT} .msr-row-bottom{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin-bottom:8px!important}
   #${ROOT} .msr-row>*:last-child,#${ROOT} .msr-row-bottom>*:last-child{grid-column:1/-1}
   #${ROOT} .msr-card{min-height:178px!important;margin:0!important;padding:10px!important}
   #${ROOT} .msr-kicker{font-size:10px!important}
   #${ROOT} .msr-mainline strong{font-size:20px!important}
   #${ROOT} .msr-mainline small{font-size:11px!important}
   #${ROOT} .msr-ring{width:66px!important;height:66px!important}
   #${ROOT} .msr-status-item strong{font-size:10.5px!important}
   #${ROOT} .msr-status-item small{font-size:9px!important}
   #${ROOT} .msqa8267#msQuickAsk8267{left:8px!important;right:8px!important;bottom:max(6px,env(safe-area-inset-bottom))!important;height:58px!important;min-height:58px!important;padding:6px!important}
   #${ROOT} .msqa8267-row{height:46px!important;min-height:46px!important;grid-template-columns:minmax(0,1fr) 46px!important}
   #${ROOT} .msqa8267 input{height:46px!important;min-height:46px!important;font-size:13px!important}
   #${ROOT} .msqa8267-send{width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important}
   #${ROOT} .msqa8267-label,#${ROOT} .msqa8267-examples,#${ROOT} .ms8271-tools{display:none!important}
 }
 /* 8.32.0 — desktop Victron + Serenity AI naast elkaar */
 @media(min-width:951px){
   #${ROOT} .ms8263-main{
     grid-template-rows:clamp(142px,19vh,178px) minmax(0,1fr)!important;
     padding:0 1.25vw .8vh!important;
     overflow:visible!important;
   }
   #${ROOT} .msr-vrm-live{
     width:66.6%!important;
     max-width:66.6%!important;
     min-width:0!important;
     justify-self:start!important;
     align-self:stretch!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267{
     position:absolute!important;
     z-index:10020!important;
     top:calc(clamp(142px,19vh,178px) + .55vh)!important;
     right:1.25vw!important;
     bottom:.8vh!important;
     left:auto!important;
     width:31.4%!important;
     height:auto!important;
     min-height:0!important;
     max-height:none!important;
     margin:0!important;
     padding:12px!important;
     display:flex!important;
     flex-direction:column!important;
     gap:8px!important;
     border:1px solid rgba(45,175,218,.42)!important;
     border-radius:17px!important;
     background:linear-gradient(145deg,rgba(4,42,61,.985),rgba(2,24,38,.99))!important;
     box-shadow:inset 0 1px rgba(255,255,255,.04),0 10px 22px rgba(0,0,0,.18)!important;
     overflow:hidden!important;
     -webkit-backdrop-filter:none!important;
     backdrop-filter:none!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-label{
     position:static!important;
     display:flex!important;
     align-items:center!important;
     width:auto!important;
     min-height:28px!important;
     margin:0!important;
     color:#fff!important;
     font-size:13px!important;
     font-weight:850!important;
     letter-spacing:.02em!important;
     text-transform:none!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-label:before{
     margin-right:8px!important;
     font-size:18px!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-row{
     display:grid!important;
     grid-template-columns:minmax(0,1fr) 42px!important;
     gap:7px!important;
     width:100%!important;
     height:44px!important;
     min-height:44px!important;
     margin:0!important;
     padding:0!important;
     border:0!important;
     background:transparent!important;
     box-shadow:none!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-spark{display:none!important}
   #${ROOT} .msqa8267#msQuickAsk8267 input{
     width:100%!important;
     height:44px!important;
     min-height:44px!important;
     padding:0 12px!important;
     border:1px solid rgba(81,149,177,.38)!important;
     border-radius:10px!important;
     background:rgba(17,60,78,.62)!important;
     color:#fff!important;
     font-size:12px!important;
     font-weight:600!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-send{
     width:42px!important;
     height:44px!important;
     min-width:42px!important;
     min-height:44px!important;
     border-radius:10px!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .ms8271-tools{
     position:static!important;
     display:flex!important;
     align-items:center!important;
     width:auto!important;
     height:auto!important;
     margin:0!important;
     gap:6px!important;
     flex-wrap:nowrap!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 #ms8271Mic,
   #${ROOT} .msqa8267#msQuickAsk8267 #ms8271Clear{
     display:grid!important;
     place-items:center!important;
     width:38px!important;
     height:36px!important;
     min-width:38px!important;
     min-height:36px!important;
     padding:0!important;
     border:1px solid rgba(94,169,198,.34)!important;
     border-radius:9px!important;
     background:rgba(12,54,72,.72)!important;
     color:#fff!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 #ms8271Mic span,
   #${ROOT} .msqa8267#msQuickAsk8267 #ms8271Clear span,
   #${ROOT} .msqa8267#msQuickAsk8267 .ms8271-speak,
   #${ROOT} .msqa8267#msQuickAsk8267 .ms8271-ai-note,
   #${ROOT} .msqa8267#msQuickAsk8267 .ms8271-voice-status{display:none!important}
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-examples{
     position:static!important;
     width:auto!important;
     height:auto!important;
     min-height:0!important;
     margin:0!important;
     padding:7px 9px!important;
     border:1px solid rgba(69,150,182,.20)!important;
     border-radius:9px!important;
     background:rgba(9,45,63,.42)!important;
     color:#a9c2ce!important;
     font-size:8.5px!important;
     line-height:1.28!important;
     overflow:visible!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-result{
     position:static!important;
     left:auto!important;
     right:auto!important;
     bottom:auto!important;
     display:block!important;
     flex:1 1 auto!important;
     width:100%!important;
     min-height:0!important;
     max-height:none!important;
     margin:0!important;
     padding:12px!important;
     border:1px solid rgba(89,199,238,.25)!important;
     border-radius:12px!important;
     background:rgba(1,14,23,.78)!important;
     color:#e7f1f5!important;
     font-size:12px!important;
     line-height:1.45!important;
     white-space:pre-line!important;
     overflow:auto!important;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-result:empty:before{
     content:"Antwoorden van Serenity AI verschijnen hier.";
     color:#6f91a1;
   }
   #${ROOT} .msqa8267#msQuickAsk8267 .msqa8267-result strong{
     color:#39ddfa!important;
     font-size:11px!important;
   }
 }
 @supports(height:100dvh){#${ROOT}{height:100dvh!important;min-height:100dvh!important}}
`;
 document.head.appendChild(s);
}

function syncBuild(){
 try{window.APP_BUILD=BUILD;window.MIJSERENITY_BUILD=BUILD}catch(_){}
 document.querySelector('meta[name="mijnserenity-build"]')?.setAttribute('content',BUILD);
 document.querySelector('meta[name="ms-build"]')?.setAttribute('content',BUILD);
 const stamp=$('buildStamp');if(stamp)stamp.textContent='v'+BUILD;
 const settings=$('settingsAppVersion');if(settings)settings.textContent=BUILD;
 document.querySelectorAll('[data-ms-build-version]').forEach(el=>el.textContent=BUILD);
}

function route(){try{return((location.hash||'#dashboard').replace(/^#/,'').split(/[?&/]/)[0]||'dashboard').toLowerCase()}catch(_){return'dashboard'}}
function setHomeActive(active){document.body.classList.toggle('ms8263-home-active',!!active);const root=$(ROOT);if(root)root.style.setProperty('display',active?'block':'none','important')}
function rootQuery(sel){return $(ROOT)?.querySelector(sel)||null}
function closeMore(){rootQuery('.ms8263-sheet')?.classList.remove('open')}

function externalClick(target){
 const aliases=target==='planner'?['planner','route']:target==='map'?['map','waterkaarten']:[target];
 const root=$(ROOT);
 for(const name of aliases){
   for(const selector of [`.tabs [data-target="${name}"]`,`.bottom-nav-item[data-target="${name}"]`,`[data-route="${name}"]`,`[data-target="${name}"]`]){
     const el=[...document.querySelectorAll(selector)].find(node=>!root?.contains(node));
     if(el){el.click();return true}
   }
 }
 return false;
}
function nav(target){
 if(!target)return;
 if(target==='dashboard'){
   try{history.replaceState(null,'',location.pathname+location.search+'#dashboard')}catch(_){}
   setHomeActive(true);apply();return;
 }
 if(target==='more'){rootQuery('.ms8263-sheet')?.classList.add('open');return}
 closeMore();setHomeActive(false);
 try{history.replaceState(null,'',location.pathname+location.search+'#'+target)}catch(_){}
 try{if(typeof window.captainNavigate==='function'){window.captainNavigate(target);return}}catch(_){}
 if(externalClick(target))return;
 try{if(typeof window.navigateTo==='function'){window.navigateTo(target);return}}catch(_){}
 try{if(typeof window.showPage==='function'){window.showPage(target)}}catch(_){}
}

function dateText(){try{return new Intl.DateTimeFormat('nl-NL',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date())}catch(_){return''}}
function shortDate(){try{return new Intl.DateTimeFormat('nl-NL',{weekday:'short',day:'numeric',month:'short',year:'numeric'}).format(new Date())}catch(_){return''}}
function greeting(){const h=new Date().getHours();return h<12?'Goedemorgen':h<18?'Goedemiddag':'Goedenavond'}
function metric(ic,id,label){return `<div class="ms8263-metric">${icon[ic]}<strong id="${id}">—</strong><small>${label}</small></div>`}
function status(target,ic,label,id,sub){return `<button type="button" class="ms8263-status-card" data-ms8263-go="${target}">${icon[ic]}<small>${label}</small><strong id="${id}">—</strong><em id="${sub}"></em></button>`}
function feature(target,ic,title,sub,tone){return `<button type="button" class="ms8263-feature ${tone}" data-ms8263-go="${target}">${icon[ic]}<span class="copy"><strong>${title}</strong><small>${sub}</small></span><span class="chev">›</span></button>`}

function clean(v){return String(v??'').replace(/\s+/g,' ').trim()}
function sourceText(ids){for(const id of ids){const t=clean($(id)?.textContent);if(t&&t!=='—'&&t!=='–')return t}return''}
function numberFrom(v){const m=String(v||'').replace(',','.').match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):NaN}
function setText(id,value){const el=$(id);if(el&&value!==undefined&&value!==null)el.textContent=String(value)}
function fmtNum(n,d=1){return Number.isFinite(n)?n.toLocaleString('nl-NL',{minimumFractionDigits:d,maximumFractionDigits:d}):''}

function refreshData(){
 const kmh=numberFrom(sourceText(['ms71510Speed','liveSpeed','speedValue','currentSpeed']));
 const kn=Number.isFinite(kmh)?kmh/1.852:NaN;
 setText('ms8263Speed',Number.isFinite(kn)?`${fmtNum(kn,kn<1?1:0)} kn`:'0 kn');
 const depthN=numberFrom(sourceText(['ms71510Depth','liveDepth','depthValue']));
 setText('ms8263Depth',Number.isFinite(depthN)?`${fmtNum(depthN,1)} m`:'Geen meting');
 const wind=sourceText(['ms71510WindBft','ms71510Wind','liveWind','windValue']);
 setText('ms8263Wind',Number.isFinite(numberFrom(wind))?clean(wind):'Geen meting');

 const soc=sourceText(['ms8264House','ms71510HouseSoc','houseSoc','batterySoc','victronSoc']);
 const socN=numberFrom(soc);
 setText('ms8263Soc',Number.isFinite(socN)?`${Math.round(socN)}%`:'—%');
 const volt=sourceText(['ms71510HouseVoltage','liveHouseVoltage','houseVoltage']);
 const amp=sourceText(['ms71510HouseCurrent','houseCurrent','batteryCurrent']);
 const vN=numberFrom(volt),aN=numberFrom(amp);
 setText('ms8263BatterySub',[Number.isFinite(vN)?`${fmtNum(vN,2)} V`:'',Number.isFinite(aN)?`${aN>0?'+':''}${fmtNum(aN,1)} A`:''].filter(Boolean).join(' · ')||'Live via Victron');

 const temp=sourceText(['ms8264Outside','outsideTemperature','weatherTemperature','weatherCurrentTemp','currentTemperature','msWeatherTemperature']);
 const tN=numberFrom(temp);
 setText('ms8263Outside',Number.isFinite(tN)?`${fmtNum(tN,1)}°`:'—°');
 setText('ms8263OutsideSub',Number.isFinite(tN)?'Actueel weer':'Weer laden…');
}

function startGps(){
 const val=$('ms8263Location'),sub=$('ms8263LocationSub');
 if(!val||!sub)return;
 if(!navigator.geolocation){val.textContent='GPS niet beschikbaar';sub.textContent='Locatie niet ondersteund';return}
 val.textContent='GPS zoeken…';sub.textContent='Positie wordt bepaald';
 navigator.geolocation.getCurrentPosition(pos=>{
   val.textContent='GPS actief';
   sub.textContent=`${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`;
   setText('msrGpsState','GPS actief');setText('msrGpsCoords',pos.coords.latitude.toFixed(4)+', '+pos.coords.longitude.toFixed(4));
 },()=>{
   val.textContent='GPS wachten';sub.textContent='Locatie nog niet beschikbaar';setText('msrGpsState','GPS wachten');
 },{enableHighAccuracy:false,timeout:7000,maximumAge:60000});
}

function updateClock(){
 setText('ms8280Clock',new Intl.DateTimeFormat('nl-NL',{hour:'2-digit',minute:'2-digit'}).format(new Date()));
 setText('ms8280HeroDate',shortDate());
 setText('ms8280Greeting','Welkom Desi & Michel');
}


function setRing(id,value){
 const el=$(id),v=Math.max(0,Math.min(100,Number(value)||0));
 if(el)el.style.setProperty('--p',String(v));
}
function decorateReference(){
 const ex=document.querySelector('#'+ROOT+' .msqa8267-examples');
 if(ex&&!ex.dataset.msrDecorated){
   ex.dataset.msrDecorated='1';
   ex.innerHTML='<strong>Voorbeeldvragen</strong>“Hoe is de accuspanning?”<br>“Plan een route naar Sneek”<br>“Wat is het weer morgen?”';
 }
}
function syncReference(){
 decorateReference();
 const speed=sourceText(['ms71510Speed','liveSpeed','speedValue','currentSpeed']);
 const speedN=numberFrom(speed);
 setText('msrSpeed',Number.isFinite(speedN)?fmtNum(speedN/1.852,speedN<1?1:0)+' kn':'0 kn');
 const depth=numberFrom(sourceText(['ms71510Depth','liveDepth','depthValue']));
 if(Number.isFinite(depth))setText('msrDepth',fmtNum(depth,1)+' m');
 const wind=sourceText(['ms71510WindBft','ms71510Wind','liveWind','windValue']);
 if(wind&&/\d/.test(wind))setText('msrWind',clean(wind));else setText('msrWind','ZW 2 Bft');

 const liveEnergy=window.MIJSERENITY_VRM_LIVE_ENERGY&&typeof window.MIJSERENITY_VRM_LIVE_ENERGY==='object'?window.MIJSERENITY_VRM_LIVE_ENERGY:null;
 const liveAt=Date.parse(String(liveEnergy?.sampledAt||''));
 const liveFresh=!!liveEnergy&&(!Number.isFinite(liveAt)||Date.now()-liveAt<=10*60*1000);
 const liveBattery=liveEnergy?.battery||{};
 const directSoc=Number(liveBattery?.soc?.value??liveBattery?.soc);
 const directVoltage=Number(liveBattery?.voltage?.value??liveBattery?.voltage);
 const directCurrent=Number(liveBattery?.current?.value??liveBattery?.current);
 const house=liveFresh&&Number.isFinite(directSoc)?directSoc:numberFrom(sourceText(['ms8264House','ms71510HouseSoc','houseSoc','batterySoc','victronSoc']));
 const hp=Number.isFinite(house)?Math.max(0,Math.min(100,Math.round(house))):48;
 setText('msrHousePct',hp+'%');setRing('msrHouseRing',hp);
 const lowHouse=liveFresh&&Number.isFinite(directVoltage)&&directVoltage<12.0;
 const ring=$('msrHouseRing'),gauge=ring?.closest('.msr-gauge');
 ring?.classList.toggle('low',lowHouse);gauge?.classList.toggle('low',lowHouse);
 const hs=sourceText(['ms8264HouseSub']);
 if(liveFresh&&Number.isFinite(directVoltage)){
   const parts=[fmtNum(directVoltage,2)+' V'+(lowHouse?' · LAAG':'')];
   if(Number.isFinite(directCurrent))parts.push((directCurrent>0?'+':'')+fmtNum(directCurrent,1)+' A');
   setText('msrHouseSub',parts.join(' · '));
 }else if(hs)setText('msrHouseSub',hs);

 const startText=sourceText(['ms8264Start','startBatteryVoltage','techStartVoltage']);
 if(startText)setText('msrStartSub',startText+'\nSpanning in orde');

 const fuel=numberFrom(sourceText(['ms8264Fuel']));
 if(Number.isFinite(fuel)){
   const fp=Math.max(0,Math.min(100,Math.round(fuel)));
   setText('msrFuelPct',fp+'%');
   const fb=$('msrFuelBar');if(fb)fb.style.width=fp+'%';
 }
 const water=numberFrom(sourceText(['ms8264Water']));
 if(Number.isFinite(water)){
   const wp=Math.max(0,Math.min(100,Math.round(water)));
   setText('msrWaterPct',wp+'%');setText('msrWaterPct2',wp+'%');
   setRing('msrWaterRing',wp);
   const wb=$('msrWaterBar');if(wb)wb.style.width=wp+'%';
 }
 const wsub=sourceText(['ms8264WaterSub']);if(wsub)setText('msrWaterSub',wsub);

 const outside=numberFrom(sourceText(['ms8264Outside','outsideTemperature','weatherTemperature','weatherCurrentTemp','currentTemperature','msWeatherTemperature']));
 if(Number.isFinite(outside)){
   const txt=fmtNum(outside,1)+'°';
   setText('msrWeatherTemp',txt);
   const hero=$('msrHeroTemp');if(hero)hero.innerHTML=txt+'<br><small style="font-size:10px;font-weight:600">Onbewolkt</small>';
 }
 const liveBadge=clean($('ms8264LiveBadge')?.textContent);
 setText('msrLiveText',liveBadge&&liveBadge!=='Verbinden…'?liveBadge:'Live');
 const solar=sourceText(['ms8264SolarSub']);if(solar)setText('msrSolarSub',solar);
}


const HEATER_KEY='mijnserenity_nordkapp_dashboard';
function readHeater(){
 try{return Object.assign({power:false,auto:true,temp:20},JSON.parse(localStorage.getItem(HEATER_KEY)||'{}'))}
 catch(_){return{power:false,auto:true,temp:20}}
}
function saveHeater(next){
 const state=Object.assign(readHeater(),next||{});
 state.temp=Math.max(8,Math.min(30,Math.round(Number(state.temp)||20)));
 try{localStorage.setItem(HEATER_KEY,JSON.stringify(state))}catch(_){}
 renderHeater(state);
 window.dispatchEvent(new CustomEvent('mijnserenity:heater-control',{detail:Object.assign({source:'dashboard'},state)}));
}
function renderHeater(state=readHeater()){
 const power=$('msrHeaterPower'),auto=$('msrHeaterAuto');
 setText('msrHeaterTemp',state.temp+'°');
 setText('msrHeaterState',state.power?'Aan · '+state.temp+'°':(state.auto?'Stand-by · Auto':'Uit'));
 if(power){power.classList.toggle('on',!!state.power);power.setAttribute('aria-pressed',String(!!state.power));power.querySelector('span').textContent=state.power?'Aan':'Uit'}
 if(auto){auto.classList.toggle('on',!!state.auto);auto.setAttribute('aria-pressed',String(!!state.auto))}
}
function bindHeater(){
 $('msrHeaterPower')?.addEventListener('click',()=>{const s=readHeater();saveHeater({power:!s.power})});
 $('msrHeaterDown')?.addEventListener('click',()=>{const s=readHeater();saveHeater({temp:s.temp-1})});
 $('msrHeaterUp')?.addEventListener('click',()=>{const s=readHeater();saveHeater({temp:s.temp+1})});
 $('msrHeaterAuto')?.addEventListener('click',()=>{const s=readHeater();saveHeater({auto:!s.auto})});
 renderHeater();
}


const ALARM_SNOOZE_KEY='mijnserenity_alarm_banner_snooze_v8301';
const ALARM_SNOOZE_MS=15*60*1000;
function alarmBannerFingerprint(banner){
 const title=clean(banner?.querySelector('strong')?.textContent);
 const body=clean(banner?.querySelector('p')?.textContent);
 return title||body?`${title}|${body}`:'';
}
function readAlarmSnooze(){
 try{return JSON.parse(sessionStorage.getItem(ALARM_SNOOZE_KEY)||'null')||{fp:'',until:0}}catch(_){return{fp:'',until:0}}
}
function installAlarmCloseFix(){
 if(window.__msAlarmCloseFix8301)return;window.__msAlarmCloseFix8301=true;
 const save=fp=>{try{sessionStorage.setItem(ALARM_SNOOZE_KEY,JSON.stringify({fp,until:Date.now()+ALARM_SNOOZE_MS}))}catch(_){}};
 const suppress=()=>{
   const banner=$('msSerenityAlarmBanner');if(!banner)return;
   const fp=alarmBannerFingerprint(banner),state=readAlarmSnooze();
   if(state.fp&&fp&&state.fp!==fp){try{sessionStorage.removeItem(ALARM_SNOOZE_KEY)}catch(_){};return}
   if(state.fp&&state.fp===fp&&Number(state.until)>Date.now())banner.classList.remove('show');
 };
 document.addEventListener('click',event=>{
   const btn=event.target?.closest?.('#msSerenityAlarmBanner .ms-alarm-close');if(!btn)return;
   const banner=$('msSerenityAlarmBanner'),fp=alarmBannerFingerprint(banner);
   if(fp)save(fp);
   setTimeout(()=>banner?.classList.remove('show'),0);
 },true);
 const observe=()=>{if(!document.body)return;const mo=new MutationObserver(suppress);mo.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class'],characterData:true});suppress()};
 if(document.body)observe();else document.addEventListener('DOMContentLoaded',observe,{once:true});
 setInterval(suppress,1200);
}

function bindQuickFeatureReveal(root){
 const grid=root.querySelector('.ms8263-features');
 const features=[...root.querySelectorAll('.ms8263-feature[data-ms8263-go]')];
 if(!grid||!features.length)return;

 const isTouchLike=()=>window.matchMedia?.('(hover: none), (pointer: coarse)')?.matches===true;
 const closeAll=except=>features.forEach(card=>{
   if(card!==except){
     card.classList.remove('msr-feature-expanded');
     card.setAttribute('aria-expanded','false');
   }
 });
 const openCard=card=>{
   closeAll(card);
   card.classList.add('msr-feature-expanded');
   card.setAttribute('aria-expanded','true');
 };

 // Desktop/muis: bepaal de actieve kaart vanuit de VASTE grid-positie.
 // Daardoor blijft de hoverzone op zijn plaats terwijl de kaart zelf omhoog schuift.
 if(grid.dataset.msrStableHoverBound!=='1'){
   grid.dataset.msrStableHoverBound='1';
   grid.addEventListener('pointermove',event=>{
     if(isTouchLike()||event.pointerType==='touch')return;
     const rect=grid.getBoundingClientRect();
     if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom){
       closeAll();return;
     }
     const styles=getComputedStyle(grid);
     const gap=parseFloat(styles.columnGap||styles.gap||'0')||0;
     const count=features.length;
     const cell=(rect.width-gap*(count-1))/count;
     const relX=event.clientX-rect.left;
     const index=Math.max(0,Math.min(count-1,Math.floor(relX/(cell+gap))));
     const startX=index*(cell+gap);
     if(relX>=startX&&relX<=startX+cell)openCard(features[index]);
     else closeAll();
   },{passive:true});
   grid.addEventListener('pointerleave',event=>{
     if(!isTouchLike()&&event.pointerType!=='touch')closeAll();
   },{passive:true});
 }

 // Touch: eerste tik opent, tweede tik navigeert.
 features.forEach(card=>{
   if(card.dataset.msrRevealBound==='1')return;
   card.dataset.msrRevealBound='1';
   card.setAttribute('aria-expanded','false');
   card.addEventListener('click',event=>{
     if(isTouchLike()){
       if(!card.classList.contains('msr-feature-expanded')){
         event.preventDefault();event.stopPropagation();
         openCard(card);
         return;
       }
       closeAll();
       nav(card.dataset.ms8263Go);
       return;
     }
     nav(card.dataset.ms8263Go);
   });
 });

 if(root.dataset.msrRevealOutsideBound!=='1'){
   root.dataset.msrRevealOutsideBound='1';
   document.addEventListener('pointerdown',event=>{
     if(!isTouchLike())return;
     const inside=event.target?.closest?.('#'+ROOT+' .ms8263-feature');
     if(!inside)closeAll();
   },{passive:true});
 }
}
function bind(){
 const root=$(ROOT);if(!root)return;
 installAlarmCloseFix();
 root.querySelectorAll('[data-ms8263-go]:not(.ms8263-feature)').forEach(b=>b.addEventListener('click',()=>nav(b.dataset.ms8263Go)));
 bindQuickFeatureReveal(root);
 $('ms8263Theme')?.addEventListener('click',()=>{
   const day=root.dataset.theme==='day';root.dataset.theme=day?'night':'day';
   setText('ms8263ThemeLabel',day?'Nacht':'Dag');
 });
 bindHeater();
 rootQuery('.ms8263-sheet')?.addEventListener('click',e=>{if(e.target.classList.contains('ms8263-sheet'))closeMore()});
 rootQuery('.ms8263-sheet-close')?.addEventListener('click',closeMore);
}


const MSVRM_TOKEN_KEYS=['ms7148_vrm_token','ms7148VrmToken','mijnserenity_vrm_token','vrm_api_token'];
const MSVRM_EMAIL_KEY='mijnserenity_vrm_mqtt_email';
let msVrmBusy=false,msVrmReadyTimer=0;

function msVrmSavedToken(){
 for(const key of MSVRM_TOKEN_KEYS){
   try{
     const value=String(localStorage.getItem(key)||'').trim().replace(/^Token\s+/i,'');
     if(value)return value;
   }catch(_){}
 }
 return '';
}
function msVrmSaveToken(value){
 const token=String(value||'').trim().replace(/^Token\s+/i,'');
 if(!token)return '';
 for(const key of MSVRM_TOKEN_KEYS){try{localStorage.setItem(key,token)}catch(_){}}
 return token;
}
function msVrmSavedEmail(){
 try{return String(localStorage.getItem(MSVRM_EMAIL_KEY)||'').trim()}catch(_){return''}
}
function msVrmSaveEmail(value){
 const email=String(value||'').trim();
 if(email.includes('@')){try{localStorage.setItem(MSVRM_EMAIL_KEY,email)}catch(_){};return email}
 return '';
}
function msVrmSetStatus(text,state='loading'){
 const panel=$('ms8319ConsolePanel');
 const label=$('ms8319ConsoleStatus');
 const overlay=$('ms8319ConsoleOverlay');
 if(label)label.textContent=text;
 panel?.classList.toggle('ms8319-ready',state==='ready');
 panel?.classList.toggle('ms8319-error',state==='error');
 if(overlay){
   overlay.classList.toggle('hidden',state==='ready');
   overlay.classList.toggle('error',state==='error');
   const copy=overlay.querySelector('[data-ms8319-status]');
   if(copy)copy.textContent=text;
 }
}
function msVrmShowSetup(show=true,message=''){
 const setup=$('ms8319TokenSetup'),normal=$('ms8319ConsoleNormal');
 setup?.classList.toggle('hidden',!show);
 normal?.classList.toggle('hidden',show);
 if(message){const msg=$('ms8319TokenMessage');if(msg)msg.textContent=message}
 if(show){
   const email=$('ms8319VrmEmail');if(email&&!email.value)email.value=msVrmSavedEmail();
   setTimeout(()=>$('ms8319VrmToken')?.focus(),80);
 }
}
async function msVrmConfig(token){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),10000);
 try{
   const response=await fetch('/api/victron-console-config',{
     method:'POST',
     cache:'no-store',
     headers:{'x-vrm-token':token,'accept':'application/json'},
     signal:controller.signal
   });
   const data=await response.json().catch(()=>({}));
   if(!response.ok||data?.success===false)throw new Error(data?.error||('HTTP '+response.status));
   return data;
 }finally{clearTimeout(timer)}
}
function msVrmFrameUrl(config,token){
 const email=msVrmSaveEmail(config?.email||msVrmSavedEmail());
 if(!email)throw new Error('Vul één keer het e-mailadres van je Victron VRM-account in.');
 const payload={
   id:String(config?.portalId||''),
   shard:String(config?.shard||''),
   mqtt:String(config?.mqttWebhost||''),
   user:email,
   pass:'Token '+token
 };
 if(!payload.id||!payload.shard)throw new Error('Geen live console-configuratie ontvangen.');
 return '/victron-gui/index.html#msconfig='+encodeURIComponent(JSON.stringify(payload));
}
function msVrmKickResize(frame){
 if(!frame)return;
 [80,250,700,1400].forEach(delay=>setTimeout(()=>{
   try{frame.contentWindow?.dispatchEvent(new Event('resize'))}catch(_){}
 },delay));
}
function msVrmWatch(frame){
 clearInterval(msVrmReadyTimer);
 let count=0;
 msVrmReadyTimer=setInterval(()=>{
   count++;
   try{
     if(frame?.contentWindow?.guiv2initialized===true){
       clearInterval(msVrmReadyTimer);
       msVrmSetStatus('Console geladen','ready');
       return;
     }
   }catch(_){}
   if(count>=40){
     clearInterval(msVrmReadyTimer);
     const overlay=$('ms8319ConsoleOverlay');
     if(overlay)overlay.classList.add('hidden');
     const label=$('ms8319ConsoleStatus');if(label)label.textContent='Console geladen';
   }
 },500);
}
async function msVrmConnect(force=false){
 const frame=$('ms8319ConsoleFrame');
 if(!frame||msVrmBusy)return false;
 if(!force&&frame.dataset.started==='1')return true;
 const token=msVrmSavedToken();
 if(!token){
   msVrmSetStatus('VRM koppelen','error');
   msVrmShowSetup(true,'Plak je VRM API-token. Deze wordt alleen op dit apparaat opgeslagen.');
   return false;
 }
 msVrmBusy=true;
 frame.dataset.started='1';
 msVrmShowSetup(false);
 msVrmSetStatus('Verbinden…','loading');
 try{
   const config=await msVrmConfig(token);
   const target=msVrmFrameUrl(config,token);
   frame.onload=()=>{
     msVrmKickResize(frame);
     setTimeout(()=>{
       const overlay=$('ms8319ConsoleOverlay');
       if(overlay)overlay.classList.add('hidden');
       const label=$('ms8319ConsoleStatus');if(label)label.textContent='Console geladen';
     },900);
   };
   frame.src=target;
   msVrmSetStatus('Cerbo GX verbinden…','loading');
   msVrmWatch(frame);
   return true;
 }catch(error){
   frame.dataset.started='0';
   const msg=error?.name==='AbortError'?'Victron verbinding time-out':String(error?.message||'Console kon niet verbinden.');
   msVrmSetStatus(msg,'error');
   if(/token|toegang|account|e-mailadres|email/i.test(msg))msVrmShowSetup(true,msg);
   return false;
 }finally{msVrmBusy=false}
}
function msVrmReload(){
 const frame=$('ms8319ConsoleFrame');if(!frame)return;
 clearInterval(msVrmReadyTimer);
 frame.dataset.started='0';
 frame.src='about:blank';
 msVrmSetStatus('Opnieuw verbinden…','loading');
 setTimeout(()=>msVrmConnect(true),120);
}
function msVrmFullscreen(){
 const active=document.body.classList.toggle('ms8319-console-full');
 const button=$('ms8319ConsoleExpand');
 if(button){button.textContent=active?'↙':'↗';button.title=active?'Console verkleinen':'Console schermvullend'}
 msVrmKickResize($('ms8319ConsoleFrame'));
}
function msVrmMount(){
 const panel=$('ms8318ConsolePanel');
 if(!panel)return false;
 window.__msVrmEmbed8313=true;
 window.__msVrmEmbed8314=true;
 window.__msVrmEmbed8318=true;
 window.__msVictronIsolated8318=true;

 if(!$('ms8319ConsoleStyle')){
   const style=document.createElement('style');
   style.id='ms8319ConsoleStyle';
   style.textContent=
     '#'+ROOT+' #ms8319ConsolePanel{grid-template-rows:44px minmax(0,1fr)!important;background:#01080d!important}'+
     '#'+ROOT+' .ms8319-head{display:flex;align-items:center;gap:10px;padding:6px 10px 6px 12px;border-bottom:1px solid rgba(37,172,219,.28);background:linear-gradient(90deg,#061b29,#03121c);color:#fff}'+
     '#'+ROOT+' .ms8319-v{display:grid;place-items:center;width:30px;height:30px;border-radius:9px;background:#0d77b8;font-weight:900}'+
     '#'+ROOT+' .ms8319-copy{min-width:0;flex:1;line-height:1.05}#'+ROOT+' .ms8319-copy strong{display:block;font-size:12px}#'+ROOT+' .ms8319-copy small{display:block;margin-top:3px;color:#8fb7ca;font-size:8.5px}'+
     '#'+ROOT+' .ms8319-state{padding:5px 8px;border:1px solid rgba(68,171,208,.28);border-radius:999px;background:#062536;color:#bcd2dc;font-size:8.5px;font-weight:800;white-space:nowrap}'+
     '#'+ROOT+' .ms8319-tools{display:flex;gap:5px}#'+ROOT+' .ms8319-tools button{display:grid;place-items:center;width:31px;height:31px;min-height:31px;padding:0;border:1px solid rgba(63,176,217,.30);border-radius:9px;background:#092b3d;color:#fff;font-size:15px;cursor:pointer}'+
     '#'+ROOT+' .ms8319-view{position:relative;min-height:0;height:100%;overflow:hidden;background:#000}#'+ROOT+' #ms8319ConsoleFrame{display:block;width:100%!important;height:100%!important;min-height:360px!important;border:0!important;background:#000!important}'+
     '@media(min-width:901px){#'+ROOT+' #ms8319ConsolePanel{min-height:390px!important}#'+ROOT+' .ms8319-view{min-height:346px!important}}'+
     '#'+ROOT+' .ms8319-overlay{position:absolute;inset:0;z-index:4;display:grid;place-items:center;padding:18px;background:#01080d;color:#c5d7e1;text-align:center;font-size:11px;line-height:1.45;transition:opacity .2s ease}#'+ROOT+' .ms8319-overlay.hidden{opacity:0;pointer-events:none}#'+ROOT+' .ms8319-overlay.error{background:#10090b;color:#ffd4d4}'+
     '#'+ROOT+' .ms8319-spinner{width:27px;height:27px;margin:0 auto 10px;border:3px solid rgba(94,190,235,.18);border-top-color:#42baff;border-radius:50%;animation:ms8319spin .85s linear infinite}@keyframes ms8319spin{to{transform:rotate(360deg)}}'+
     '#'+ROOT+' .ms8319-setup{width:min(100%,440px);padding:16px;border:1px solid rgba(77,184,230,.30);border-radius:14px;background:#071c2a;text-align:left;color:#eef8fd}#'+ROOT+' .ms8319-setup.hidden{display:none}#'+ROOT+' .ms8319-normal.hidden{display:none}'+
     '#'+ROOT+' .ms8319-setup h3{margin:0 0 6px;font-size:16px}#'+ROOT+' .ms8319-setup p{margin:0 0 10px;color:#aac4d0;font-size:10px}#'+ROOT+' .ms8319-setup input{box-sizing:border-box;width:100%;height:38px;margin:0 0 7px;padding:0 10px;border:1px solid rgba(88,190,235,.35);border-radius:9px;background:#020d14;color:#fff;font-size:12px}#'+ROOT+' .ms8319-setup button{width:100%;min-height:38px;border:1px solid rgba(88,190,235,.34);border-radius:9px;background:#0878bd;color:#fff;font-weight:800}'+
     'body.ms8319-console-full #'+ROOT+' #ms8319ConsolePanel{position:fixed!important;inset:8px!important;z-index:2147483000!important;height:auto!important;border-radius:16px!important}'+
     '@media(max-width:900px) and (orientation:portrait){#'+ROOT+' #ms8319ConsolePanel{height:720px!important;min-height:720px!important;margin-bottom:10px!important}#'+ROOT+' .ms8319-copy small{display:none}}';
   document.head.appendChild(style);
 }

 panel.id='ms8319ConsolePanel';
 panel.dataset.ms8318Rendered='1';
 panel.innerHTML=
   '<div class="ms8319-head">'+
     '<div class="ms8319-v">V</div>'+
     '<div class="ms8319-copy"><strong>Victron Cerbo GX · Remote Console</strong><small>Donkere live console · bediening blijft binnen MijnSerenity</small></div>'+
     '<div class="ms8319-state" id="ms8319ConsoleStatus">Verbinden…</div>'+
     '<div class="ms8319-tools"><button type="button" id="ms8319ConsoleReload" title="Console vernieuwen">↻</button><button type="button" id="ms8319ConsoleExpand" title="Console schermvullend">↗</button></div>'+
   '</div>'+
   '<div class="ms8319-view">'+
     '<div class="ms8319-overlay" id="ms8319ConsoleOverlay">'+
       '<div class="ms8319-normal" id="ms8319ConsoleNormal"><div class="ms8319-spinner"></div><strong data-ms8319-status>Live Cerbo-console wordt voorbereid…</strong></div>'+
       '<form class="ms8319-setup hidden" id="ms8319TokenSetup" autocomplete="off">'+
         '<h3>Victron koppelen</h3><p id="ms8319TokenMessage">Gebruik je VRM API-token. Vul je VRM e-mailadres alleen in als dit niet automatisch wordt gevonden.</p>'+
         '<input id="ms8319VrmEmail" type="email" autocapitalize="none" spellcheck="false" placeholder="VRM e-mailadres (optioneel)">'+
         '<input id="ms8319VrmToken" type="password" autocapitalize="none" spellcheck="false" placeholder="VRM API-token" required>'+
         '<button type="submit">Opslaan en verbinden</button>'+
       '</form>'+
     '</div>'+
     '<iframe id="ms8319ConsoleFrame" title="Victron Cerbo GX Remote Console" allow="fullscreen; clipboard-read; clipboard-write" referrerpolicy="no-referrer"></iframe>'+
   '</div>';

 $('ms8319ConsoleReload')?.addEventListener('click',msVrmReload);
 $('ms8319ConsoleExpand')?.addEventListener('click',msVrmFullscreen);
 $('ms8319TokenSetup')?.addEventListener('submit',event=>{
   event.preventDefault();
   const email=$('ms8319VrmEmail')?.value||'';
   if(email)msVrmSaveEmail(email);
   const token=msVrmSaveToken($('ms8319VrmToken')?.value||'');
   if(!token){msVrmSetStatus('Plak eerst je VRM API-token.','error');return}
   const frame=$('ms8319ConsoleFrame');if(frame)frame.dataset.started='0';
   msVrmShowSetup(false);
   msVrmConnect(true);
 });
 msVrmConnect(false);
 return true;
}

function apply(){
 const root=$(ROOT);if(!root)return false;
 installStyle();syncBuild();setHomeActive(true);
 root.className='ms8255-reference-home ms8263-approved-home';
 root.dataset.approved='8280';root.dataset.theme='night';
 root.innerHTML=`
 <div class="msr-shell">
  <aside class="msr-side">
    <div class="msr-brand"><strong>Serenity</strong><div class="msr-wave"></div><small>MY BOAT · MY FREEDOM</small></div>
    <nav class="msr-nav" aria-label="Hoofdnavigatie">
      <button class="active" data-ms8263-go="dashboard">${icon.home}<span>Home</span></button>
      <button data-ms8263-go="live">${icon.route}<span>Varen</span></button>
      <button data-ms8263-go="map">${icon.map}<span>Kaart</span></button>
      <button data-ms8263-go="logbook">${icon.log}<span>Logboek</span></button>
      <button data-ms8263-go="technical">${icon.gear}<span>Techniek</span></button>
      <button data-ms8263-go="weather">${icon.sun}<span>Weer</span></button>
      <button data-ms8263-go="planner">${icon.route}<span>Reisplanner</span></button>
      <button data-ms8263-go="ais">${icon.radar}<span>AIS</span></button>
      <button data-ms8263-go="pois">${icon.pin}<span>POI</span></button>
      <button data-ms8263-go="settings">${icon.gear}<span>Instellingen</span></button>
    </nav>
    <div class="msr-side-foot"><div class="sun">☼</div><strong>Serenity</strong>Varen is leven</div>
  </aside>

  <section class="msr-hero">
    <img class="msr-hero-bg" src="/serenity-dashboard-boat-sharp-20260927.jpg?v=${TOKEN}" alt="" aria-hidden="true" decoding="async" fetchpriority="high">
    <div class="msr-hero-copy"><strong id="ms8280Greeting">Welkom Desi &amp; Michel</strong><span>Fijn dat jullie er weer zijn</span><em>“Good vibes, high tides”</em></div>
    <div class="msr-hero-info">
      <div class="msr-hero-date" id="ms8280HeroDate">${shortDate()}</div>
      <div class="msr-hero-moon">☾</div>
      <div class="msr-hero-time" id="ms8280Clock">--:--</div>
      <div class="msr-hero-temp" id="msrHeroTemp">17,7°<br><small style="font-size:10px;font-weight:600">Onbewolkt</small></div>
      <div class="msr-hero-pin">⌖</div><div class="msr-hero-place">Enschede</div>
    </div>
  </section>

  <main class="ms8263-main">
    <section class="msr-panel msr-quick">
      <div class="msr-quick-head"><strong>SNEL NAAR</strong><button class="msr-edit" data-ms8263-go="settings">Bewerk ✎</button></div>
      <section class="ms8263-features">
        ${feature('technical','battery','Energie',"Accu's & laden",'green')}
        ${feature('technical','cloud','Tanks','Water, diesel, vuilwater','cyan')}
        ${feature('technical','gear','Techniek','Motor, verwarming, systemen','orange')}
        ${feature('map','map','Kaart','Waterkaarten & navigatie','purple')}
        ${feature('logbook','log','Logboek','Nieuwe logregel','navy')}
        ${feature('planner','route','Reisplanner','Plan je volgende trip','green')}
      </section>
    </section>

    <section class="msr-vrm-live" id="ms8318ConsolePanel" aria-label="Victron Cerbo GX Remote Console">
      <div style="display:flex;align-items:center;gap:10px;padding:6px 10px 6px 12px;background:linear-gradient(90deg,#061b29,#03121c);border-bottom:1px solid rgba(37,172,219,.28);color:#fff">
        <div style="display:grid;place-items:center;width:30px;height:30px;border-radius:9px;background:#0d77b8;font-weight:900">V</div>
        <div style="min-width:0;flex:1;line-height:1.05"><strong style="display:block;font-size:12px">Victron Cerbo GX · Remote Console</strong><small style="display:block;margin-top:3px;color:#8fb7ca;font-size:8.5px">Donkere live console · bediening blijft binnen MijnSerenity</small></div>
        <div style="padding:5px 8px;border:1px solid rgba(68,171,208,.28);border-radius:999px;background:#062536;color:#bcd2dc;font-size:8.5px;font-weight:800">STARTEN…</div>
      </div>
      <div style="display:grid;place-items:center;min-height:0;background:#01080d;color:#b9cfda;font-size:11px">Victron-console wordt geladen…</div>
    </section>

    <section class="msr-row">
      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">⌖</span>HUIDIGE LOCATIE</div></div>
        <div class="msr-mainline"><div class="bigico">⌖</div><div><strong id="msrGpsState">GPS actief</strong><small id="msrGpsCoords">52.1998, 6.9012</small></div></div>
        <div class="msr-minis">
          <div class="msr-mini"><small>Snelheid</small><strong id="msrSpeed">0 kn</strong></div>
          <div class="msr-mini"><small>Koers</small><strong>---</strong></div>
          <div class="msr-mini"><small>Diepte</small><strong id="msrDepth">2,8 m</strong></div>
        </div>
        <button class="msr-action" data-ms8263-go="map">Open kaart <span>›</span></button>
      </section>

      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">☁</span>WEER OP LOCATIE</div></div>
        <div class="msr-weather-main"><div class="msr-weather-icon">🌤️</div><div><strong id="msrWeatherTemp">17,7°</strong><small>Onbewolkt</small></div></div>
        <div class="msr-minis">
          <div class="msr-mini"><small>🌅</small><strong>07:16</strong></div>
          <div class="msr-mini"><small>🌇</small><strong>19:38</strong></div>
          <div class="msr-mini"><small>≋</small><strong id="msrWind">ZW 2 Bft</strong></div>
        </div>
        <button class="msr-action" data-ms8263-go="weather">Uitgebreid weer <span>›</span></button>
      </section>

      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">⚡</span>ACCU'S &amp; ENERGIE</div><span class="msr-live"><i></i><span id="msrLiveText">Live</span></span></div>
        <div class="msr-rings">
          <div class="msr-gauge"><div class="msr-ring" id="msrHouseRing" style="--p:48"><strong id="msrHousePct">48%</strong></div><label>Huishoudaccu</label><small id="msrHouseSub">13,06 V · -4,6 A</small></div>
          <div class="msr-gauge"><div class="msr-ring" id="msrStartRing" style="--p:71"><strong>71%</strong></div><label>Startaccu</label><small id="msrStartSub">12,76 V<br>Spanning in orde</small></div>
          <div class="msr-gauge"><div class="msr-ring" id="msrWaterRing" style="--p:0"><strong id="msrWaterPct">0%</strong></div><label>Drinkwater</label><small id="msrWaterSub">0 L<br>Victron tank</small></div>
        </div>
        <button class="msr-action" data-ms8263-go="technical">Naar energie <span>›</span></button>
      </section>
    </section>

    <section class="msr-row msr-row-bottom">
      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">💧</span>TANKS</div></div>
        <div class="msr-tankline"><span class="ticon">⛽</span><strong>Dieseltank</strong><div class="msr-bar" style="--p:71%"><i id="msrFuelBar" style="width:71%"></i></div><small id="msrFuelPct">71%</small><span>›</span></div>
        <div class="msr-tankline water"><span class="ticon">💧</span><strong>Drinkwater</strong><div class="msr-bar"><i id="msrWaterBar" style="width:0%"></i></div><small id="msrWaterPct2">0%</small><span>›</span></div>
        <div class="msr-tankline water"><span class="ticon">▣</span><strong>Vuilwatertank</strong><div class="msr-bar"><i style="width:100%"></i></div><small>100%</small><span>›</span></div>
        <button class="msr-action" data-ms8263-go="technical">Alle tanks <span>›</span></button>
      </section>

      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">⚙</span>SYSTEEMSTATUS</div></div>
        <div class="msr-status-grid">
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>Victron GX</strong><small>Online</small></div></div>
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>Walstroom</strong><small>Niet actief</small></div></div>
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>SmartShunt</strong><small>Actief</small></div></div>
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>Motor</strong><small>Stand-by</small></div></div>
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>Zonnepanelen</strong><small id="msrSolarSub">Laden (20,1 V)</small></div></div>
          <div class="msr-status-item"><span class="msr-check">✓</span><div><strong>Nordkapp GEN3</strong><small id="msrHeaterState">Stand-by · Auto</small></div></div>
        </div>
        <div class="msr-heater" aria-label="Bijverwarming">
          <button type="button" id="msrHeaterPower" class="msr-heater-power" aria-pressed="false">⏻ <span>Uit</span></button>
          <div class="msr-heater-temp" aria-label="Gewenste temperatuur">
            <button type="button" id="msrHeaterDown" aria-label="Temperatuur lager">−</button>
            <strong id="msrHeaterTemp">20°</strong>
            <button type="button" id="msrHeaterUp" aria-label="Temperatuur hoger">+</button>
          </div>
          <button type="button" id="msrHeaterAuto" class="msr-heater-auto on" aria-pressed="true">AUTO</button>
        </div>
        <button class="msr-action" data-ms8263-go="technical">Naar techniek <span>›</span></button>
      </section>

      <section class="msr-panel msr-card">
        <div class="msr-card-title"><div class="msr-kicker"><span class="ico">▣</span>KOMENDE ITEMS</div><button class="msr-edit" data-ms8263-go="planner">Toon alles</button></div>
        <div class="msr-upcoming">
          <div class="msr-upcoming-item"><span class="uico">🛒</span><strong>Morgen 08:00</strong><span>Boodschappen en proviand</span></div>
          <div class="msr-upcoming-item"><span class="uico">🔧</span><strong>21 sep</strong><span>Onderhoud checklist</span></div>
          <div class="msr-upcoming-item"><span class="uico">⛽</span><strong>23 sep</strong><span>Diesel bijvullen (indicatie)</span></div>
          <div class="msr-upcoming-item"><span class="uico">⛵</span><strong>Weekend</strong><span>Proefvaart / testen</span></div>
        </div>
        <button class="msr-action" data-ms8263-go="planner">Naar reisplanner <span>›</span></button>
      </section>
    </section>

    <section class="ms8263-status msr-hidden-anchor" aria-hidden="true"></section>
    <section class="ms8263-welcome" aria-hidden="true"><button type="button" class="ms8263-start" data-ms8263-go="live">Live varen</button></section>
  </main>
 </div>`;
 // Mount de Victron-console direct. Zo kan een fout in een andere Home-widget
 // de console op desktop niet meer blokkeren.
 try{msVrmMount()}catch(error){console.warn('Victron Home Console mount:',error)}
 try{bind()}catch(error){console.warn('Home bind:',error)}
 try{refreshData()}catch(error){console.warn('Home refresh:',error)}
 try{startGps()}catch(error){console.warn('Home GPS:',error)}
 try{updateClock()}catch(error){console.warn('Home clock:',error)}
 try{decorateReference()}catch(error){console.warn('Home decorate:',error)}
 setTimeout(()=>{try{syncReference()}catch(_){}},120);
 setTimeout(()=>{try{syncReference()}catch(_){}},1200);
 clearInterval(window.__ms8263RefreshTimer);
 window.__ms8263RefreshTimer=setInterval(()=>{refreshData();syncReference();updateClock()},2000);
 return true;
}

window.ms8263ApplyApprovedDashboard=apply;
window.ms8260ApplyApprovedDashboard=apply;
window.ms8263Navigate=nav;
window.ms8263MountVictronConsole=msVrmMount;

// Desktop/Safari failsafe: als Home opnieuw wordt opgebouwd en het startpaneel
// nog zichtbaar is, monteer alleen de console opnieuw.
clearInterval(window.__ms8263VictronMountWatch);
window.__ms8263VictronMountWatch=setInterval(()=>{
  if(route()!=='dashboard')return;
  if($('ms8318ConsolePanel')){
    try{msVrmMount()}catch(error){console.warn('Victron console watchdog:',error)}
  }
},1000);

function start(){if(route()==='dashboard'){if(!apply())setTimeout(start,80)}else setHomeActive(false)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
window.addEventListener('pageshow',()=>{if(route()==='dashboard')setTimeout(apply,20)},{passive:true});
window.addEventListener('hashchange',()=>{if(route()==='dashboard')setTimeout(apply,30);else setHomeActive(false)},{passive:true});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&route()==='dashboard'){refreshData();updateClock()}},{passive:true});
})();
