/* MijnSerenity 7.19.0 — startaccu in dezelfde layout als huishoudaccu
   Event-driven: geen dashboardbrede MutationObserver en geen 5s polling. */
(()=>{
  'use strict';
  if(window.__msStartBatterySoc71900)return;
  window.__msStartBatterySoc71900=true;

  const $=id=>document.getElementById(id);
  const num=value=>{const match=String(value??'').replace(',','.').match(/-?\d+(?:\.\d+)?/);return match?Number(match[0]):null};
  const setText=(id,value)=>{const el=$(id);if(el&&el.textContent!==String(value))el.textContent=String(value)};
  const readNumber=ids=>{for(const id of ids){const value=num($(id)?.textContent);if(value!==null)return value}return null};
  const fmt=(value,digits=1)=>value===null?'–':Number(value).toLocaleString('nl-NL',{minimumFractionDigits:digits,maximumFractionDigits:digits});

  function estimatedSocFromVoltage(voltage){
    if(voltage===null||voltage<8||voltage>16)return null;
    if(voltage>=12.73)return 100;
    if(voltage<=11.50)return 0;
    const points=[[11.50,10],[11.66,20],[11.81,30],[11.96,40],[12.10,50],[12.24,60],[12.37,70],[12.50,80],[12.62,90],[12.73,100]];
    for(let i=1;i<points.length;i++){
      const [v1,s1]=points[i-1],[v2,s2]=points[i];
      if(voltage<=v2){
        const raw=s1+((voltage-v1)/(v2-v1))*(s2-s1);
        return Math.max(0,Math.min(100,Math.round(raw/5)*5));
      }
    }
    return 100;
  }

  function ensureStyle(){
    if($('msStartBatterySoc71822Style'))return;
    const style=document.createElement('style');
    style.id='msStartBatterySoc71822Style';
    style.textContent=`
#msMarineGlass .mg-start.mg-battery strong{display:block!important;color:var(--mg-green)!important;font-size:28px!important;line-height:1!important;margin:5px 0!important}
#msMarineGlass .mg-start.mg-battery em{display:inline!important;color:#b8cbd7!important;font-size:11px!important;font-style:normal!important;margin-right:8px!important}
#msMarineGlass .mg-start.mg-battery[data-soc-source="estimate"] em{color:#8fa8b8!important}`;
    document.head.appendChild(style);
  }

  function upgradeCard(){
    const card=document.querySelector('#msMarineGlass .mg-start');
    if(!card)return false;
    card.classList.add('mg-battery','mg-start-battery');
    if(!$('mgStartSoc'))card.innerHTML='<small>Startaccu</small><strong id="mgStartSoc">–%</strong><span id="mgStartV">– V</span><em id="mgStartAmp">SOC geschat</em>';
    return true;
  }

  function sync(){
    ensureStyle();
    if(!upgradeCard())return;
    const card=document.querySelector('#msMarineGlass .mg-start-battery');
    const voltage=readNumber(['ms71510StartVoltage','techStartVoltage','liveStartVoltage','mgStartV']);
    const measuredSoc=readNumber(['ms71510StartSoc','techStartSoc','ivmsStartSoc']);
    const current=readNumber(['ms71510StartCurrent','techStartCurrent','ivmsStartCurrent']);
    const soc=measuredSoc!==null?Math.max(0,Math.min(100,Math.round(measuredSoc))):estimatedSocFromVoltage(voltage);
    setText('mgStartSoc',soc===null?'–%':`${soc}%`);
    setText('mgStartV',voltage===null?'– V':`${fmt(voltage,1)} V`);
    setText('mgStartAmp',current===null?(measuredSoc!==null?'SOC gemeten':'SOC geschat'):`${fmt(current,1)} A`);
    if(card)card.dataset.socSource=measuredSoc!==null?'measured':'estimate';
  }

  let frame=0;
  function queue(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;sync()})}
  function start(){
    queue();
    setTimeout(queue,300);
    setTimeout(queue,1200);
    ['mijnserenity-ha-state-updated','mijnserenity-ha-connected','mijnserenity-vrm-updated','mijnserenity-vrm-energy-live-updated','mijnserenity-vrm-diagnostics-updated','mijnserenity:dashboard-ready']
      .forEach(name=>window.addEventListener(name,queue,{passive:true}));
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)queue()},{passive:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
