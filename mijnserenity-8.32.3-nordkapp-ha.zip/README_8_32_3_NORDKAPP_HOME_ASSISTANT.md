# MijnSerenity 8.32.3 — Nordkapp en Home Assistant

Deze update zet het Home Assistant-veld voor de dieselverwarming standaard op
`climate.nordkapp_heater`, de entiteit die de Nordkapp Heater-integratie aanmaakt.
Een eerder opgeslagen eigen entiteit blijft behouden.

## Eerst Home Assistant instellen

De Nordkapp-kachel moet via Bluetooth beschikbaar zijn voor Home Assistant. De
integratie vermeldt dat de kachel BLE uitzendt als deze aan staat; bij uitgeschakelde
kachel kan automatische ontdekking niet werken.

1. Voeg in HACS de aangepaste repository `https://github.com/MSDATDE/nordkapp_heater`
   toe als **Integration**.
2. Installeer **Nordkapp Heater** en herstart Home Assistant.
3. Open **Instellingen → Apparaten en diensten → Integratie toevoegen → Nordkapp Heater**
   en ontdek of voeg de kachel toe.
4. Controleer in **Instellingen → Apparaten en diensten → Entiteiten** of
   `climate.nordkapp_heater` beschikbaar is.

## Serenity koppelen

1. Open **Meer → Home Assistant → Instellen** in MijnSerenity.
2. Maak of controleer de bestaande beveiligde koppeling.
3. Het veld **Dieselverwarming** is vooraf ingevuld met `climate.nordkapp_heater`.
   Controleer dat dit overeenkomt met de entiteit in Home Assistant.
4. Kopieer de gegenereerde configuratie naar Home Assistant, controleer deze en
   herstart Home Assistant.
5. Voer `rest_command.mijnserenity_sync` één keer uit. Controleer daarna in Serenity
   bij **Techniek** of de verwarmingsstatus wordt bijgewerkt.

De app neemt de status van de klimaatentiteit over als **Uit** of **In bedrijf**.
De weergegeven sensoren op het HA-apparaat kunnen in een latere uitbreiding ook
apart aan het technische dashboard worden gekoppeld.

## Bron en beperking

De Nordkapp-integratie is een onofficiële Home Assistant-integratie. Lees de
projectinformatie voordat je deze installeert. Deze update installeert geen
integratie in Home Assistant en verandert geen HA-configuratie.
